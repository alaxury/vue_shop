<template>
    <div>WELCOM222E</div>
</template>

<script>
export default {

}
</script>

<style lang="less" scoped>
div{
    background-color: red;
}
</style>
